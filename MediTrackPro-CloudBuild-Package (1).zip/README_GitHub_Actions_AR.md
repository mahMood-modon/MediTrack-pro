# بناء MediTrack Pro APK من الموبايل بدون AndroidIDE

هذه الطريقة تستخدم GitHub Actions لبناء APK على خوادم GitHub، ولا تحتاج Android SDK أو Gradle على هاتفك.

## الملفات
- `MediTrackPro-Android.zip`: مشروع Android المصدر.
- `build-apk.yml`: إعداد البناء الذي يجب وضعه داخل مستودع GitHub في المسار `.github/workflows/build-apk.yml`.

## الخطوات

### 1) أنشئ مستودع GitHub
1. افتح https://github.com/new في Chrome وسجل الدخول.
2. Repository name: `MediTrackPro-Builder`.
3. اختر Private (أو Public إذا كنت تريد نشر ملفات المشروع علنًا).
4. اضغط Create repository.

### 2) أضف ملف إعداد البناء
1. داخل المستودع اضغط Add file ثم Create new file.
2. في خانة اسم الملف اكتب بالضبط: `.github/workflows/build-apk.yml`
3. افتح ملف `build-apk.yml` المرفق في هذه الحزمة وانسخ محتواه كاملًا، ثم الصقه في محرر GitHub.
4. اضغط Commit changes.

> لا ترفع ملف YAML إلى جذر المستودع فقط؛ يجب أن يكون في المسار `.github/workflows/build-apk.yml` لكي يتعرف GitHub Actions عليه.

### 3) ارفع مشروع Android المضغوط
1. ارجع إلى الصفحة الرئيسية للمستودع.
2. اضغط Add file ثم Upload files.
3. ارفع `MediTrackPro-Android.zip` إلى جذر المستودع (وليس ملف ZIP الكبير الذي يحتوي على هذا الدليل).
4. اضغط Commit changes.

### 4) شغّل البناء
1. افتح تبويب Actions في المستودع.
2. اختر Build MediTrack Pro APK من القائمة الجانبية.
3. اضغط Run workflow ثم زر Run workflow الأخضر.
4. افتح عملية البناء التي تظهر وانتظر حتى تصبح خضراء (Success). أول بناء قد يستغرق بضع دقائق لأن أدوات Android وGradle تُنزَّل على الخادم.

### 5) نزّل APK
1. داخل صفحة عملية البناء الناجحة، انزل إلى قسم Artifacts.
2. اضغط `MediTrackPro-debug-apk` لتنزيل ملف ZIP الناتج.
3. افتح ملف ZIP في تطبيق الملفات على هاتفك واستخرج `MediTrackPro-debug.apk`.
4. اضغط على APK لتثبيته. إذا طلب Android السماح بتثبيت تطبيقات من هذا المصدر، اسمح به لمتصفح/مدير الملفات الذي استخدمته ثم أكمل التثبيت.

## إذا فشل البناء
- افتح عملية Actions الحمراء، ثم افتح خطوة Build MediTrack Pro APK أو الخطوة التي عليها علامة ×.
- انسخ نص الخطأ أو أرسل Screenshot؛ غالبًا يمكن تحديد السبب من سجل البناء.

## ملاحظات مهمة
- هذا ينتج Debug APK للتجربة والاستخدام الشخصي، وليس APK منشورًا على متجر Google Play.
- لا ترفع كلمات مرور أو مفاتيح توقيع خاصة إلى المستودع.
- المشروع لا يحتاج AndroidIDE على الهاتف بهذه الطريقة. يلزم الإنترنت وقت البناء والتنزيل؛ التطبيق بعد تثبيته مصمم لفتح واجهته محليًا.
