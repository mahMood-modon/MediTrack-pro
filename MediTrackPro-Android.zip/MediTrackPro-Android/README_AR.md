# MediTrack Pro — Android APK Project

هذا مشروع Android حقيقي يحوّل واجهة MediTrack الحالية إلى تطبيق APK مستقل باستخدام Android WebView، مع حفظ بيانات HTML محليًا، وإشعارات Android أصلية للجرعة.

## أسهل طريقة للبناء من الموبايل

### AndroidIDE
1. ثبّت AndroidIDE على هاتف Android من مصدره الرسمي/المتجر المتاح لديك.
2. فك ضغط `MediTrackPro-Android.zip`.
3. افتح مجلد المشروع في AndroidIDE.
4. انتظر Gradle Sync حتى ينتهي.
5. من Build اختر `assembleDebug`.
6. ستجد APK داخل:
   `app/build/outputs/apk/debug/app-debug.apk`
7. ثبّت APK على هاتفك.

> أول Build يحتاج إنترنت لتنزيل Gradle/Android Gradle Plugin حسب بيئة البناء. بعد ذلك التطبيق نفسه لا يحتاج إنترنت.

## على الكمبيوتر
افتح المشروع في Android Studio ثم Build > Build APK(s).

## ملاحظات
- package: `com.meditrack.pro`
- التطبيق يبدأ افتراضيًا على COPAD 10,000 كما هو منطق النسخة الحالية.
- إعداد وقت التذكير في التطبيق يضبط AlarmManager أصليًا.
- Android 13+ سيطلب إذن الإشعارات أول مرة.
- بيانات التطبيق داخل WebView محفوظة في localStorage/IndexedDB ولا يتم حذفها بمجرد إغلاق التطبيق.
