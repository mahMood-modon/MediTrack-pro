package com.meditrack.pro;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import java.util.Calendar;

public final class ReminderScheduler {
    private ReminderScheduler() {}
    public static void schedule(Context c, int hour, int minute) {
        c.getSharedPreferences("meditrack", Context.MODE_PRIVATE).edit().putInt("hour",hour).putInt("minute",minute).apply();
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi=pending(c);
        Calendar cal=Calendar.getInstance(); cal.set(Calendar.HOUR_OF_DAY,hour); cal.set(Calendar.MINUTE,minute); cal.set(Calendar.SECOND,0); cal.set(Calendar.MILLISECOND,0);
        if(cal.getTimeInMillis()<=System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR,1);
        am.cancel(pi); am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
    }
    public static void scheduleNext(Context c) {
        int h=c.getSharedPreferences("meditrack",Context.MODE_PRIVATE).getInt("hour",16);
        int m=c.getSharedPreferences("meditrack",Context.MODE_PRIVATE).getInt("minute",0);
        schedule(c,h,m);
    }
    public static void cancel(Context c) { ((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).cancel(pending(c)); }
    private static PendingIntent pending(Context c){
        Intent i=new Intent(c, ReminderReceiver.class);
        return PendingIntent.getBroadcast(c, 2001, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
