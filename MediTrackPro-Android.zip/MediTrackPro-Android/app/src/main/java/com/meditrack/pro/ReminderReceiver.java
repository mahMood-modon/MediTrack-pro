package com.meditrack.pro;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    public static final String CHANNEL_ID = "meditrack_reminders";
    @Override public void onReceive(Context context, Intent intent) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "تذكيرات MediTrack", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("تذكير بموعد الجرعة");
            nm.createNotificationChannel(ch);
        }
        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(context, 10, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new android.app.Notification.Builder(context, CHANNEL_ID) : new android.app.Notification.Builder(context);
        b.setSmallIcon(com.meditrack.pro.R.mipmap.ic_launcher)
         .setContentTitle("MediTrack 💊")
         .setContentText("حان وقت مراجعة الجرعة وتسجيلها بعد أخذها فعليًا.")
         .setAutoCancel(true).setContentIntent(pi).setPriority(android.app.Notification.PRIORITY_HIGH);
        nm.notify(1001, b.build());
        ReminderScheduler.scheduleNext(context);
    }
}
