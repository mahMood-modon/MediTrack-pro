package com.meditrack.pro;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.app.Activity;

public class MainActivity extends Activity {
    private WebView web;
    private static final int NOTIF_REQ=501;
    @Override protected void onCreate(Bundle savedInstanceState){ super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(244,247,252));
        web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setMediaPlaybackRequiresUserGesture(false); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient()); web.addJavascriptInterface(new NativeBridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
        createChannel();
    }
    private void createChannel(){ if(Build.VERSION.SDK_INT>=26){ NotificationManager nm=getSystemService(NotificationManager.class); nm.createNotificationChannel(new NotificationChannel(ReminderReceiver.CHANNEL_ID,"تذكيرات MediTrack",NotificationManager.IMPORTANCE_HIGH)); } }
    @JavascriptInterface public void requestNotificationPermission(){ runOnUiThread(()->{ if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIF_REQ); else ReminderScheduler.scheduleNext(this); }); }
    @JavascriptInterface public void setReminder(String hhmm){ try{ String[] p=hhmm.split(":"); ReminderScheduler.schedule(this,Integer.parseInt(p[0]),Integer.parseInt(p[1])); }catch(Exception ignored){} }
    @JavascriptInterface public void cancelReminder(){ ReminderScheduler.cancel(this); }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    private class NativeBridge {
        @JavascriptInterface public void requestNotificationPermission(){ MainActivity.this.requestNotificationPermission(); }
        @JavascriptInterface public void setReminder(String t){ MainActivity.this.setReminder(t); }
        @JavascriptInterface public void cancelReminder(){ MainActivity.this.cancelReminder(); }
    }
}
